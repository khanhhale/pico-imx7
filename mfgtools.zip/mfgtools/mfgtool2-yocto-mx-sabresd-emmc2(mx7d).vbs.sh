#
./mfgtoolcli  -l eMMC -s board=sabresd -s sxdtb=sdb -s mmc=2 
#
